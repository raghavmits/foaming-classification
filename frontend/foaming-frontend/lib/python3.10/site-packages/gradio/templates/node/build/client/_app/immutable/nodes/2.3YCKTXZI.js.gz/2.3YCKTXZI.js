import { N, _ } from "../chunks/2.m1a33O_T.js";
export {
  N as component,
  _ as universal
};
